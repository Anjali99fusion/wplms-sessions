<?php
/*
Plugin Name: WPLMS Sessions
Plugin URI: http://www.VibeThemes.com
Description: custom plugin for sesion per user 
Version: 1.0
Author: vibethemes
Author URI: http://www.VibeThemes.com
Text Domain: wplms-se
Domain Path: /languages/
*/

/**
 * Register important functions for WPLMS
 *
 * @author      VibeThemes
 * @category    Admin
 * @package     Initialization
 * @version     2.0
 */

if ( !defined( 'ABSPATH' ) ) exit;

class WPLMS_Sessions{

    public static $instance;
    
    public static function init(){

        if ( is_null( self::$instance ) )
            self::$instance = new WPLMS_Sessions();

        return self::$instance;
    }

    private function __construct(){

        add_filter('lms_general_settings',array($this,'add_session_setting_in_lms'));
        add_action( 'bp_after_profile_field_content', array( $this, 'setup_settings_buddypress' ) );
        add_filter( 'authenticate',array($this,'limit_number_of_sessions_per_user'), 30, 3 );
        add_action( 'init', array( $this, 'limit_number_of_sessions_per_user' ) );

    	}

       // $x = apply_filters('wplms_one_session','add_session_setting_in_lms',10,1);
        
        function add_session_setting_in_lms($array){
           $array[]= array(
                    'label' => __('Limit Number Of Sessions Per User','vibe-customtypes'),
                        'name' => 'limit_session_per_user',
                        'type' => 'number',
                        'desc' => __('Limit Number of Sessions for a Single User','vibe-customtypes')
                );
            return $array;
        }


        function setup_settings_buddypress($m){
            ?>
            Limit Number of Sessions Per User: <input type="text" name="limit_sessions" id="limmit_sessions_per_user">
            <?php
        }

       function limit_number_of_sessions_per_user( $user, $username, $password ) { 
        
        if(isset($user->allcaps['edit_posts']) && $user->allcaps['edit_posts']){
            return $user;
        }
        $sessions = WP_Session_Tokens::get_instance( $user->ID );

        $all_sessions = $sessions->get_all();
        echo count($all_sessions);
        if ( count($all_sessions) > $x ) {
            $flag=0;
            $previous_login = get_user_meta($user->ID,'last_activity',true);
            if(isset($previous_login) && $previous_login){
                $threshold = apply_filters('wplms_login_threshold',1800);
                $difference = time()-strtotime($previous_login) - $threshold;
                if($difference <= 0){ // If the user Logged in within 30 Minutes
                    $flag=1;
                }else{
                    $token = wp_get_session_token();
                    $sessions->destroy_others( $token );
                } 
            }else{
                $flag = 1;
            }
            if($flag)
                $user = new WP_Error('already_signed_in', __('<strong>ERROR</strong>: User already logged in.','vibe-customtypes'));
        }
        return $user;
    }


}

WPLMS_Sessions::init();